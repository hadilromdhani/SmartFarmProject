#include <gtk/gtk.h>


void
on_Confirmer_modif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SM_supprimer_ouv_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Spprimer_conf_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_SMbuttonAjouter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_SMbuttonModifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_SMbutton_consulter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour_Ouv_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_SMbuttonconnex_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SM_consulter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_SMbuttonPresence_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_retour_consulter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_confirmer_ajout_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour_Ajout_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonModifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonAjouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SM_consulter_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonPresence_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour_Ouv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonconnex_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttonouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbuttoncreation_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_suppri_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Supprimer_ouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SM_checkbutton_pres_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SM_checkbutton_abs_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SM_radiobutton_male_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SM_radiobutton_femelle_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_valider_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button_taux_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button_retour_cal_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttoncalcul_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SM_retour_presence_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_SMbutton_rech_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);


