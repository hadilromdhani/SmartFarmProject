#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdlib.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ouvrier.h"
#include <string.h>
int radio;
int choix[2]={0,0};
void
on_Confirmer_modif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{       
        ouvrier o;
	//o.sexe="Femme";
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *input6;
	GtkWidget *output1;
	GtkWidget *combobox2;
        GtkWidget *radiobutton_femme ;
        GtkWidget *radiobutton_homme;
	char succes[30];

        //GtkWidget *modifier;
       // GtkWidget *gestion;
        //modifier =lookup_widget(objet,"modifier");
	
	input1=lookup_widget(objet ,"SMentrycin");
	input2=lookup_widget(objet ,"SMentrynom");
	input3=lookup_widget(objet ,"SMentryprenom");
	input4=lookup_widget(objet ,"SMentryspec");
        input5=lookup_widget(objet ,"SMentryadresse");
	input6=lookup_widget(objet ,"SMentrynumero");
	combobox2=lookup_widget(objet ,"SMcombobox");

        output1=lookup_widget(objet ,"SM_label");
	strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(o.specialite,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(o.ntel,gtk_entry_get_text(GTK_ENTRY(input6)));
        strcpy(o.ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	  strcpy(succes,"Modification avec succés");
         gtk_label_set_text(GTK_LABEL (output1), succes);
	strcpy(o.sexe,"Femme");
        if(radio==1)
             {
            strcpy(o.sexe,"Homme");
             }
        else if(radio==2)
            {
            strcpy(o.sexe,"Femme");
             }

	modifier_ouvrier(o);
     /* GdkColor color;
      gdk_color_parse("red",&color);
      gtk_widget_modify_fg( output1 ,GTK_STATE_NORMAL ,&color);*/
      strcpy(succes,"Modification avec succés");
         gtk_label_set_text(GTK_LABEL (output1), succes);
      // gtk_widget_destroy(modifier);
      // gestion =create_gestion();
      //gtk_widget_show(gestion);


}



void
on_retour_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
        GtkWidget *modifier_ouvrier;
	GtkWidget *consulter_ouvrier;
	GtkWidget *treeview1;
	modifier_ouvrier=lookup_widget(objet,"modifier_ouvrier");
        gtk_widget_destroy(modifier_ouvrier);
        consulter_ouvrier=lookup_widget(objet,"consulter_ouvrier");
	consulter_ouvrier=create_consulter_ouvrier();
         gtk_widget_show(consulter_ouvrier);
	
	treeview1=lookup_widget(consulter_ouvrier,"treeview1");
         afficher_ouvrier(treeview1);
}


void
on_Spprimer_conf_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
       GtkWidget *supprimer_ouvrier ,*gestion_ouvrier;
       
	ouvrier o;
        GtkWidget *input1;
	supprimer_ouvrier=lookup_widget(objet,"supprimer_ouvrier");
	
	input1=lookup_widget(supprimer_ouvrier,"SMentry_supp");
	strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
	supprimer_ouv(o);

	
        //gtk_widget_destroy(supprimer);
       // gestion=lookup_widget(objet,"consulter");
	// gestion =create_gestion();
         //gtk_widget_show(gestion);
}


void
on_retour_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
 
GtkWidget *supprimer_ouvrier;
GtkWidget *gestion_ouvrier;
supprimer_ouvrier=lookup_widget(objet,"supprimer_ouvrier");
gtk_widget_destroy(supprimer_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}


void
on_retour_consulter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_ouvrier;
GtkWidget *consulter_ouvrier;
consulter_ouvrier=lookup_widget(objet,"consulter_ouvrier");
gtk_widget_destroy(consulter_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;

       gchar *nom;
       gchar *prenom;
       gchar *cin;
       gchar *adresse;
       gchar *specialite; 
       gchar *ntel;
       gchar *sexe;
       gchar *ville;
       ouvrier o;
	
	GtkTreeModel *model =gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));
	//gtk_tree_model_get_iter(model,&iter,path);
 if(gtk_tree_model_get_iter(model,&iter,path))
{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&cin,3,&specialite,4,&adresse,5,&ntel,6,&sexe,7,&ville,-1);
	
strcpy(o.nom,nom);
strcpy(o.prenom,prenom);
strcpy(o.cin,cin);
strcpy(o.adresse,adresse);
strcpy(o.specialite,specialite);
strcpy(o.ntel,ntel);
strcpy(o.sexe,sexe);
strcpy(o.ville,ville);
//supprimer_ouvrier(o);
afficher_ouvrier(treeview);
}
}

void
on_confirmer_ajout_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
ouvrier o;
//o.sexe="Femme";
GtkWidget *input1 ,*input2,*input3,*input4,*input5,*input6;
GtkWidget *radiobutton_male , *radiobutton_femelle;
GtkWidget *combobox;
GtkWidget *Ajouter_ouvrier , *gestion_ouvrier;
Ajouter_ouvrier=lookup_widget(objet, "Ajouter_ouvrier");

input1=lookup_widget(Ajouter_ouvrier,"SM_ajout_cin");
input2=lookup_widget(Ajouter_ouvrier,"SM_ajout_nom");
input3=lookup_widget(Ajouter_ouvrier,"SM_ajout_prenom");
input4=lookup_widget(Ajouter_ouvrier,"SM_ajout_Specialite");
input5=lookup_widget(Ajouter_ouvrier,"SM_ajout_adresse");
input6=lookup_widget(Ajouter_ouvrier,"SM_ajout_Ntel");
combobox=lookup_widget(Ajouter_ouvrier,"SMcombobox1");

strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(o.specialite,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(o.ntel,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(o.ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));

strcpy(o.sexe,"Femme");
if(radio==1)
{
strcpy(o.sexe,"Homme");
}
else if(radio==2)
{
strcpy(o.sexe,"Femme");
}

ajouter_ouvrier(o);

gtk_widget_destroy(Ajouter_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);

}


void
on_Retour_Ajout_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_ouvrier;
GtkWidget *Ajouter_ouvrier;
Ajouter_ouvrier=lookup_widget(objet,"Ajouter_ouvrier");
gtk_widget_destroy(Ajouter_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}


void
on_SMbuttonModifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modifier_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
modifier_ouvrier=create_modifier_ouvrier();
gtk_widget_show(modifier_ouvrier);
}


void
on_SMbuttonAjouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
Ajouter_ouvrier=create_Ajouter_ouvrier();
gtk_widget_show(Ajouter_ouvrier);
}


void
on_SM_consulter_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_ouvrier;
GtkWidget *consulter_ouvrier;
GtkWidget *treeview1;
gestion_ouvrier=lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
consulter_ouvrier=lookup_widget(objet,"consulter_ouvrier");
consulter_ouvrier=create_consulter_ouvrier();
gtk_widget_show(consulter_ouvrier);
treeview1=lookup_widget(consulter_ouvrier,"treeview1");
afficher_ouvrier(treeview1);
}


void
on_SMbuttonPresence_clicked            (GtkWidget      *objet,
                                        gpointer         user_data)
{


GtkWidget *Presence_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier =lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
Presence_ouvrier =create_Presence_ouvrier();
gtk_widget_show(Presence_ouvrier);
}


void
on_Retour_Ouv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_ouvrier;
GtkWidget *Menu_ouvrier;
gestion_ouvrier=lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
Menu_ouvrier=create_Menu_ouvrier();
gtk_widget_show(Menu_ouvrier);
}


void
on_SMbuttonconnex_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
FILE * f=NULL;
GtkWidget *login,*pw, *Acceuil_ouvrier ;
char login1[20];
char passw[20];
login = lookup_widget(objet, "SMentry_Nom");
pw = lookup_widget(objet, "SMentry_motdepasse");
strcpy(login1, gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(passw, gtk_entry_get_text(GTK_ENTRY(pw)));
//ouvrir le fichier 
f=fopen("users.txt","a+");
if (f!=NULL)
{ 
fprintf(f,"%s %s \n",login1,passw);
}

fclose(f);
Acceuil_ouvrier =create_Acceuil_ouvrier();
gtk_widget_show (Acceuil_ouvrier);
}


void
on_SMbuttonouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ouvrier;
GtkWidget *gestion_ouvrier;
Acceuil_ouvrier=lookup_widget(objet,"Acceuil_ouvrier");
gtk_widget_destroy(Acceuil_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);

}


void
on_SMbuttoncreation_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
}




void
on_Supprimer_ouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *supprimer_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier =lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
supprimer_ouvrier=create_supprimer_ouvrier();
gtk_widget_show(supprimer_ouvrier);
}


void
on_SM_checkbutton_pres_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
{choix[0]=1;}
}


void
on_SM_checkbutton_abs_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
{choix[1]=1;}
}



void
on_SM_radiobutton_male_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
radio=1;
}


void
on_SM_radiobutton_femelle_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if( gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
radio=2;
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
radio=2;
}


void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
radio=1;
}


void
on_button_valider_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
presence a;
GtkWidget *input1;
GtkWidget *checkbox1;
GtkWidget *checkbox2;
GtkWidget *spinbutton1;
GtkWidget *spinbutton2;
GtkWidget *spinbutton3;

input1=lookup_widget(objet,"SMentryid");
spinbutton1=lookup_widget(objet,"SMjour");
spinbutton2=lookup_widget(objet,"SMmois");
spinbutton3=lookup_widget(objet,"SMannee");

strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
a.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton3));

if(choix[0]==1)
{ a.p=0;}
else
if(choix[1]==1)
{ a.p=1;}

ajouter_presence(a);

}





void
on_button_taux_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *calcul_taux;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(objet,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
calcul_taux=create_calcul_taux();
gtk_widget_show(calcul_taux);
}



void
on_button_retour_cal_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *gestion_ouvrier;
GtkWidget *calcul_taux;
calcul_taux=lookup_widget(objet,"calcul_taux");
gtk_widget_destroy(calcul_taux);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}



void
on_buttoncalcul_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget calcul_taux;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *output1;
//const char *s1;
//const char *s2;
float taux;
char ch1[30];
int mois;
int annee;
presence a;
ouvrier o;
output1=lookup_widget(objet,"taux_abs");
Mois=lookup_widget(objet,"spinbutton_mo");
Annee=lookup_widget(objet,"spinbutton_an");
a.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
a.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));
 
//s1=gtk_entry_get_text(a.mois);
//s2=gtk_entry_get_text(a.annee);
//Mois=atoi(s1);
//Annee=atoi(s2);

if(mois!=a.mois && annee!=a.annee)
{
taux = taux_absenteisme(a.mois,a.annee);
}
sprintf(ch1,"le taux vaut %f \n ",taux);
//atoi(output1);
gtk_label_set_text(GTK_LABEL(output1),ch1);
}


void
on_SM_retour_presence_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)

{
GtkWidget *gestion_ouvrier;
GtkWidget *Presence_ouvrier;
Presence_ouvrier=lookup_widget(objet,"Presence_ouvrier");
gtk_widget_destroy(Presence_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}



void
on_SMbutton_rech_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
      GtkWidget *modifier_ouvrier ;
       
	ouvrier o;
        GtkWidget *input1;
	GtkWidget *output1;
        GtkWidget *output2;
        GtkWidget *output3;
        GtkWidget *output4;
        GtkWidget *output5;
        GtkWidget *output6;
        //GtkWidget *output6;
        GtkWidget *combobox2;
        GtkWidget *radiobutton_femme ;
        GtkWidget *radiobutton_homme;
	modifier_ouvrier=lookup_widget(objet,"modifier_ouvrier");
	
	input1=lookup_widget(modifier_ouvrier,"SMentrycin");
        
	output1=lookup_widget(modifier_ouvrier ,"SMentrynom");
	output2=lookup_widget(modifier_ouvrier ,"SMentryprenom");
	output3=lookup_widget(modifier_ouvrier ,"SMentryspec");
        output4=lookup_widget(modifier_ouvrier ,"SMentryadresse");
        output5=lookup_widget(modifier_ouvrier ,"SMentrynumero");
	//radiobutton_femme =lookup_widget(modifier ,"radiobutton_femme");
	//radiobutton_homme=lookup_widget(modifier ,"radiobutton_homme");
	combobox2=lookup_widget(modifier_ouvrier ,"SMcombobox");

	
        strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(input1)));
        o=rechercher_ouvrier(o);
	gtk_entry_set_text(GTK_ENTRY(output1),o.nom);
	gtk_entry_set_text(GTK_ENTRY(output2),o.prenom);
	gtk_entry_set_text(GTK_ENTRY(output3),o.specialite);
	gtk_entry_set_text(GTK_ENTRY(output4),o.adresse);
	gtk_entry_set_text(GTK_ENTRY(output5),o.ntel);
           //strcmp(o.ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));     
        //gtk_combo_box_append_type(GTK_COMBO_BOX(combobox2),o.ville);
	//gtk_radio_button_set_group(GTK_RADIO_BUTTON(radiobutton_femme));
	//gtk_radio_button_set_group(GTK_RADIO_BUTTON(radiobutton_homme));
       //gtk_radio_button_get_group(GTK_RADIO_BUTTON(radiobutton_homme);
       
        
	
}


